

int main()
{
	int t1,start=2000000,end=2020000,mcount=0, k, n, lim, sn, p, pc=0, lastp=0, phold=0;   
	t1=sysTime(); if (start%2==0) start++; n =   start; lastp=n; lim = end; sn=n;	
	printf("Finding primes between %, and %,\n\n",n,lim);
	while (n<lim)
	{
		k = 3; p = 1; n = n + 2;
		while ((k * k <= n) && p)
		{
			p = n %k; mcount++; k = k + 2;
		}
		if (p)
		{
			pc = pc + 1; phold=n;
			if (pc%100==0)
			{
				printf("prime # %5, is %7, in this range %4.2f percent of the numbers are primes\n",pc,n,(float)10000.0/(n-lastp));
				lastp=n;
			}
		}
	}
	printf("\n\nFound %, primes\n", pc);
	printf("Last prime was %,\n\n",phold);
	int  runsec=sysTime()-t1;
	printf("It took %6.2f seconds to process\n",runsec/100.0);
	int pers=mcount/runsec*100;
	printf("%, prime verification loops were performed, that's %, per second\n",mcount,pers);
	return 1;
}