/* picoc interactive debugger */

#ifndef NO_DEBUGGER

#include "interpreter.h"
#include <stdio.h>

#define BREAKPOINT_TABLE_SIZE 21
#define BREAKPOINT_HASH(p) ( ((unsigned long)(p)->FileName) ^ (((p)->Line << 16) | (0 << 16)) )

struct Table BreakpointTable;
struct TableEntry *BreakpointHashTable[BREAKPOINT_TABLE_SIZE];
int BreakpointCount = 0;
int DebugManualBreak = FALSE;

int DebugStep(struct ParseState * Parser);


/* initialise the debugger by clearing the breakpoint table */
void DebugInit()
{
    TableInitTable(&BreakpointTable, &BreakpointHashTable[0], BREAKPOINT_TABLE_SIZE, TRUE);
    BreakpointCount = 0;
}

/* free the contents of the breakpoint table */
void DebugCleanup()
{
    struct TableEntry *Entry;
    struct TableEntry *NextEntry;
    int Count;
    
    for (Count = 0; Count < BreakpointTable.Size; Count++)
    {
        for (Entry = BreakpointHashTable[Count]; Entry != NULL; Entry = NextEntry)
        {
            NextEntry = Entry->Next;
            HeapFreeMem(Entry);
        }
    }
}

/* search the table for a breakpoint */
static struct TableEntry *DebugTableSearchBreakpoint(struct ParseState *Parser, int *AddAt)
{
    struct TableEntry *Entry;
    int HashValue = BREAKPOINT_HASH(Parser) % BreakpointTable.Size;
    
    for (Entry = BreakpointHashTable[HashValue]; Entry != NULL; Entry = Entry->Next)
    {
        if (Entry->p.b.FileName == Parser->FileName && Entry->p.b.Line == Parser->Line && Entry->p.b.CharacterPos == 0)
            return Entry;   /* found */
    }
    
    *AddAt = HashValue;    /* didn't find it in the chain */
    return NULL;
}

/* set a breakpoint in the table */
void DebugSetBreakpoint(struct ParseState *Parser)
{
    int AddAt;
    struct TableEntry *FoundEntry = DebugTableSearchBreakpoint(Parser, &AddAt);
    
    if (FoundEntry == NULL)
    {   
        /* add it to the table */
        struct TableEntry *NewEntry = HeapAllocMem(sizeof(struct TableEntry));
        if (NewEntry == NULL)
            ProgramFail(NULL, "out of memory");
            
        NewEntry->p.b.FileName = Parser->FileName;
        NewEntry->p.b.Line = Parser->Line;
        NewEntry->p.b.CharacterPos = 0;//Parser->CharacterPos;
        NewEntry->Next = BreakpointHashTable[AddAt];
        BreakpointHashTable[AddAt] = NewEntry;
        BreakpointCount++;
    }
}

/* delete a breakpoint from the hash table */
int DebugClearBreakpoint(struct ParseState *Parser)
{
    struct TableEntry **EntryPtr;
    int HashValue = BREAKPOINT_HASH(Parser) % BreakpointTable.Size;
    
    for (EntryPtr = &BreakpointHashTable[HashValue]; *EntryPtr != NULL; EntryPtr = &(*EntryPtr)->Next)
    {
        struct TableEntry *DeleteEntry = *EntryPtr;
        if (DeleteEntry->p.b.FileName == Parser->FileName && DeleteEntry->p.b.Line == Parser->Line && DeleteEntry->p.b.CharacterPos == Parser->CharacterPos)
        {
            *EntryPtr = DeleteEntry->Next;
            HeapFreeMem(DeleteEntry);
            BreakpointCount--;

            return TRUE;
        }
    }

    return FALSE;
}

extern int GCheckTrailingSemicolon;
int mybrk;

/* before we run a statement, check if there's anything we have to do with the debugger here */
void DebugCheckStatement(struct ParseState *Parser)
{
    int DoBreak = FALSE;
    int AddAt;
    
    /* has the user manually pressed break? */
    if (DebugManualBreak)
    {
        DoBreak = TRUE;
        DebugManualBreak = FALSE;
    }
    
    /* is this a breakpoint location? */
    if (BreakpointCount != 0 && DebugTableSearchBreakpoint(Parser, &AddAt) != NULL)
        DoBreak = TRUE;
    
    /* handle a break */
    mybrk=0;
    if (DoBreak)
    {
       PlatformPrintf("Handling a break\nEnter c to continue s to single step\n?xxx to list variable xxx\nbnnnn to set breakpoint, l to list program\n");
      Parser->Mode=RunModeRun;
      Parser->DebugMode=0;
          DoBreak=FALSE;
          mybrk=1;

          CurLinePrint(Parser);

    }
}

extern struct StackFrame* TopStackFrame;
const char * Ident;

void PrintValue(struct Value * Var)
{
  struct ValueType * Typ=Var->Typ;
      switch (Typ->Base)
    {
        case TypeVoid:          printf("void %x\n", Var->Val->UnsignedInteger); break;
        case TypeInt:           printf("int %d\n", Var->Val->Integer); break;
        case TypeShort:         printf("short %d\n", Var->Val->ShortInteger); break;
        case TypeChar:          printf("char %c\n", (char )Var->Val->ShortInteger); break;
        case TypeLong:          printf("long %ld\n", Var->Val->LongInteger); break;
        case TypeUnsignedInt:   printf("unsigned int %d\n", Var->Val->UnsignedInteger); break;
        case TypeUnsignedShort: printf("unsigned short %d\n", Var->Val->UnsignedShortInteger); break;
        case TypeUnsignedLong:  printf("unsigned long %lu\n", Var->Val->UnsignedLongInteger); break;
#ifndef NO_FP
        case TypeFP:            printf("double %f\n", Var->Val->FP); break;
#endif
        case TypePointer:       if (Typ->FromType) printf("%s %lx ","pointer", Var->Val->UnsignedLongInteger); printf("*\n"); break;
        case TypeArray:         printf("%s ","array"); printf("["); if (Typ->ArraySize != 0) printf("%d]\n",Typ->ArraySize); break;

        case TypeFunction:      printf("function\n");  break;
        case TypeMacro:         printf("macro\n"); break;
        case TypeStruct:        printf("struct\n");break;
        case TypeUnion:         printf("union\n"); break;
        case TypeEnum:          printf("enum\n"); break;
        case TypeGotoLabel:     printf("gotoLabel\n"); break;
        case Type_Type:         printf("type\n"); break;
    }

}
void prntLines(struct ParseState * Parser);

int DebugStep(struct ParseState * Parser)
{

          char  cln[128];
  rdchar:
          PlatformGetLine((char *)&cln[0],127, "debug-> ");
          if (cln[0]=='c')
          {
            Parser->DebugMode=0;
            DebugClearBreakpoint(Parser);
            mybrk=0;
            return ParseResultOk;
          }
          if (cln[0]=='s')
          {
            CurLinePrint(Parser);
            return ParseResultOk;
          }
          if (cln[0]=='?')
          {
            char * cp=strstr((char *)&cln[0],"\n");
            if (cp!=NULL) *cp=0;
            // print symbol
            struct Value *VariableValue = NULL;
            int rslt;
            Ident=&cln[1];
            char * mycp=TableStrRegister(Ident);
            //if (VariableDefined((char *)&cln[1]))
            {
                if (TopStackFrame!=NULL) rslt=TableGet(&TopStackFrame->LocalTable,mycp,&VariableValue,NULL,NULL,NULL);
                if (rslt==0) rslt=TableGet(&GlobalTable,mycp,&VariableValue,NULL,NULL,NULL);
            }

            if (rslt!=0) PrintValue(VariableValue);
            else printf("%s is not defined as local or global variable\n",(char *)&cln[1]);

            goto rdchar;
          }
          if (cln[0]=='l')
          {
            // list code
            prntLines(Parser);
            goto rdchar;
          }
          fflush(stdin);
          goto rdchar;


         return ParseResultOk;
}


#endif /* !NO_DEBUGGER */
