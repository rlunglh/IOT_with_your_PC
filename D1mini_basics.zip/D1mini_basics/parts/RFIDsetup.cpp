
#define FS_NO_GLOBALS
#include <FS.h>
#include <MFRC522.h>  // Library for Mifare RC522 Devices
extern boolean match;          // initialize card match to false
extern boolean programMode;  // initialize programming mode to false
extern boolean replaceMaster;

extern uint8_t successRead;    // Variable integer to keep if we have Successful Read from Reader
extern uint8_t ncards;
extern byte storedCard[4];   // Stores an ID read from File
extern byte readCard[4];   // Stores scanned ID read from RFID Module
extern byte masterCard[4];   // Stores master card's ID read from File

#define redLed D1   // Set Led Pins
#define greenLed D2
#define blueLed D3

#define relay D4    // Set Relay Pin
extern uint8_t cards[60][4];
//#define COMMON_ANODE

#ifdef COMMON_ANODE
#define LED_ON LOW
#define LED_OFF HIGH
#else
#define LED_ON HIGH
#define LED_OFF LOW
#endif

extern MFRC522 mfrc522;
extern void ShowReaderDetails();
extern uint8_t getID();
extern int indx;
void dumpFile();
void printFile();
void cycleLeds();

void RFIDsetup()
{ 
  pinMode(redLed, OUTPUT);
  pinMode(greenLed, OUTPUT);
  pinMode(blueLed, OUTPUT);
  pinMode(relay, OUTPUT);
  Serial.println();
  //Be careful how relay circuit behave on while resetting or power-cycling your Arduino
  digitalWrite(relay, HIGH);    // Make sure door is locked
  digitalWrite(redLed, LED_OFF);  // Make sure led is off
  digitalWrite(greenLed, LED_OFF);  // Make sure led is off
  digitalWrite(blueLed, LED_OFF); // Make sure led is off
  //Protocol Configuration
  mfrc522.PCD_Init();    // Initialize MFRC522 Hardware
  uint8_t val=0;
#ifdef RESET
  fs::File frs=SPIFFS.open("/locked/RFIDcard","w");
  frs.write(val);
  frs.write(val);frs.write(13);frs.write(10);
  frs.close();
#endif

  ShowReaderDetails();  // Show details of PCD - MFRC522 Card Reader details
  // Check if master card defined, if not let user choose a master card
  if (!SPIFFS.exists("/locked/RFIDcard"))
  {
    fs::File fin=SPIFFS.open("/locked/RFIDcard","w");
    uint8_t val=0;
    fin.write(val);
    val='A';
    fin.write(val);
    fin.close();
    ncards=0;
  }
  fs::File fin=SPIFFS.open("/locked/RFIDcard","r");
  uint8_t magic;
  fin.read(&magic,1);fin.read(&magic,1);
  fin.close();
  if (magic != 'X') {
    Serial.println(F("No Master Card Defined"));
    Serial.println(F("Scan A PICC to Define as Master Card"));
    do {
      successRead = getID();            // sets successRead to 1 when we get read from reader otherwise 0
      yield();
      digitalWrite(blueLed, LED_ON);    // Visualize Master Card need to be defined
      delay(200);
      digitalWrite(blueLed, LED_OFF);
      delay(200);
    }
    while (!successRead);                  // Program will not go further while not a successful read
    Serial.println("Master card read");
    fs::File fi=SPIFFS.open("/locked/RFIDcard","w");
    uint8_t val='A'+1;ncards=0;
    fi.write((uint8_t *)&val,1);
    val='X';
    fi.write((uint8_t *)&val,1);fi.write(13);fi.write(10);
    char outHex[3];outHex[2]=0;
    for (indx=0;indx<4;indx++) 
    {
      Serial.print(readCard[indx], HEX);
      masterCard[indx]=readCard[indx];
      cards[0][indx]=readCard[indx];
    }
    ncards=1;
    dumpFile();
    /*
    //sprintf((char *)&outHex,"%02x",readCard[indx]);
   // Serial.printf("%s",(char *)&outHex);
    //fin.write((uint8_t *)&outHex,2); }
      fi.print(readCard[indx], HEX); }
    fi.write(13);fi.write(10);
    fi.close();Serial.println();
    for (indx=0;indx<4;indx++) cards[ncards][indx]=readCard[indx];
    ncards++;
    //  show file content     
    */ 
    Serial.println(F("Master Card Defined"));
  }
  /*
   * char val2[3];val2[2]=0;
  fin=SPIFFS.open("/locked/RFIDcard","r");
  fin.read(&val,1);ncards=val-'A';fin.read(&val,1);fin.read(&val,1);fin.read(&val,1);
  for (indx=0;indx<4;indx++) {fin.read((uint8_t *)&val2,2);cards[0][indx]=strtol((char *)&val2,0,16);}
  fin.close();
  Serial.println(F("-------------------"));
  Serial.println(F("Master Card's UID"));
  for ( uint8_t i = 0; i < 4; i++ ) {          
   // masterCard[i] = cards[0][i];    // Write it to masterCard
    Serial.print(masterCard[i], HEX);
  }
  */
  Serial.println("");
  Serial.println(F("-------------------"));
  Serial.println(F("Everything is ready"));
  printFile();
  Serial.println(F("Waiting PICCs to be scanned"));
  cycleLeds();    // Everything ready lets give user some feedback by cycling leds
}
