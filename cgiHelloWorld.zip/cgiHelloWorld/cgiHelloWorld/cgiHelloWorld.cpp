// cguHelloWorld.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <atlstr.h>

CString getQueryTerm(char * name)
{
	char* envbuf = nullptr;
	size_t sz = 0;
	_dupenv_s(&envbuf, &sz, "QUERY_STRING");
	CString qs = envbuf;
	//printf("<center><h2>query string=%s</h2></center>", (char *)envbuf);
	CString val = "";
	char buf[32];
	strcpy_s((char *)&buf, 32, (char *)name);
	strcat_s((char *)&buf, 32, "=");
	char * eqat;
	eqat = strstr((char *)qs.GetString(), (char *)&buf);
	if (eqat != 0)
	{
		strcpy_s((char *)&buf, 32, eqat);
		eqat = strstr((char *)&buf, "=");
		eqat++;
		if (strstr(eqat, "&") != 0) *strstr(eqat, "&") = 0;
		strcpy_s((char *)&buf, 32, eqat);
		val = (char *)&buf;
	}
	free(envbuf);
	return val;
}

int main()
{
	printf("\n\n<html><head></head><title>Hello World Example</title></head><body><center>");
	CString nm = getQueryTerm("Name");
	printf("<h2>Hello World to %s</h2></center>",(char *)(LPCSTR)nm);
	printf("</body></html>");
	return 0;
}