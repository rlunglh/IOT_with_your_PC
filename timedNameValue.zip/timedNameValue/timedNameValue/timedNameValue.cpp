// weatherInsert.cpp : Defines the entry point for the console application.
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <afxdb.h>
void log(char * string)
{
	FILE * fout;
	fout = fopen("k:\\Documents\\we.log", "at");
	fputs(string, fout);
	fputs("\n",fout);
	fflush(fout);
	fclose(fout);
}
CString getQueryTerm(char * name)
{
	char* envbuf = nullptr;
	size_t sz = 0;
	CString val = "";
	_dupenv_s(&envbuf, &sz, "QUERY_STRING");
	if (envbuf == 0) { val = name;val+="_NOT_FOUND"; log("NOT FOUND");return val; }
	CString qs = envbuf;
	//printf("<center><h2>query string=%s</h2></center>", (char *)envbuf);
	char buf[64];
	strcpy_s((char *)&buf, 64, (char *)name);
	strcat_s((char *)&buf, 64, "=");
	char * eqat;
	eqat = strstr((char *)qs.GetString(), (char *)&buf);
	if (eqat != 0)
	{
		strcpy_s((char *)&buf, 64, eqat);
		eqat = strstr((char *)&buf, "=");
		eqat++;
		if (strstr(eqat, "&") != 0) *strstr(eqat, "&") = 0;
		strcpy_s((char *)&buf, 64, eqat);
		val = (char *)&buf;
	}
	free(envbuf);
	return val;
}
char mqttProgramLoc[] = "\"c:\\program files (x86)\\mosquitto\\";
int main()
{
	char buf[128];
	printf("\n\n<html><head></head><body><h2><center>timeNameValue Insert</center></h2>");
	CString nm = getQueryTerm("Name");
	CString val = getQueryTerm("Value");
	snprintf((char *)&buf, 128, "Insert into usr.timedNameValue values (Now(),'%s','%s')", (LPCSTR)nm.GetBuffer(), (LPCSTR)val.GetBuffer());
	log((char *)&buf);
	printf("<center><h2>Name=%s</h2><h2>Value=%s</h2>", (LPCSTR)nm.GetBuffer(), (LPCSTR)val.GetBuffer());
	CDatabase mdb;
	BOOL dbs = mdb.OpenEx((LPCTSTR)"DSN=MYSQL;UID=rickl;PWD=wrl-123");
	printf("<h2>Database Open status=%d</h2>", dbs);
	TRY
	{
		mdb.ExecuteSQL((LPCTSTR)&buf);
	    printf("<p>Insert statement %s</p>", (char *)&buf);
	}
	CATCH(CDBException, e) { printf("<p>Insert statement execute error %s</p>", (LPCSTR)e->m_strError.GetBuffer()); }
	END_CATCH
	mdb.Close();
	printf("<h2>Data Inserted</h2>");
	nm.Replace('_', '/');
	snprintf((char *)&buf, 128, "%smosquitto_pub\" -h localhost -r -t %s -m %s",(char *)&mqttProgramLoc, (LPCSTR)nm.GetBuffer(), (LPCSTR)val.GetBuffer());
	printf("<h2>MQTT Publication Data</h2>");
	printf((char *)&buf);
	system((char *)&buf);
	printf("</center></body></html>");
    return 0;
}

