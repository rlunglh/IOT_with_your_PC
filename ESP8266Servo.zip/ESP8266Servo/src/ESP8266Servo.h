#ifndef ESP8266Servo_h
#define ESP8266Servo_h

#if (ARDUINO >= 100)
#include <Arduino.h>
#else
#include <WProgram.h>
#endif

class ESP8266Servo
{
public:
  ESP8266Servo(int pin,int minPos,int midPos,int maxPos);
  ESP8266Servo(int pin); // initialize with 1000,1500,2000 as min,mid,max
  void setPos(float Position); // position ranges from 0.0 to 1.0
  void sweep(float toPos,float time); // change to tpPos over time seconds
  void oscillate(float fromPos,float toPos,float time); // sweep between two points over time seconds
  void sweepUpdate(); // run in loop function to execute sweep updates
  void oscillateUpdate(); // run in loop to execute oscillate updates
  void setPwmFreq(float freq); // set PwmFreq to let ESP8266Servo know pwm frequency
  void report(); // Serial output current servo information
  int doingSweeping(); // status check to inquire if doing sweeping
private:
   float pwmFreq; //used to set period accurately
   int pwmRange=32767,cycling=0;
   int pwmCount;  // records current analogWrite value
   int servoPin, minP, midP, maxP, sweeping, lastUpdate, curPos, doneUpdates;
   float deltaPos, sweepTime, updateInterval,cumPosition;
};

#endif