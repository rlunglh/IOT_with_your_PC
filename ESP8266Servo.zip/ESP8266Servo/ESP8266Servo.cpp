#include "ESP8266Servo.h"

// define DEBUG to get verbose output on Serial Monitor
//#define DEBUG

byte dpins[]=   {D0,D1,D2,D3,D4,D5,D6,D7,D8};
// dpins used to translate d1mini pin # to Arduino IDE pin #s

ESP8266Servo::ESP8266Servo(int pin,int minPos,int midPos,int maxPos)
{
	// initialize servo with defined values for min mid and max
	servoPin=pin;
	minP=minPos;
	midP=midPos;
	maxP=maxPos;
	pinMode(dpins[pin],OUTPUT);
	analogWrite(dpins[servoPin],1);
	pwmCount=1;
	sweeping=0;
#ifdef DEBUG
	Serial.printf("Pwm on pin%d:%d, duration=3276 <%d |%d >%d\n",servoPin,dpins[servoPin],minPos,midPos,maxPos);
#endif
}

int ESP8266Servo::doingSweeping()
{
	// report sweeping status
	return sweeping;
}

void ESP8266Servo::oscillate(float fromPos,float toPos,float time)
{
	// oscillate between fromPos and toPos over time
  	int cp,cp2;
	if (toPos<=0.5)
	{
		cp=(midP-minP)*toPos/0.5+minP;
	}
	else
	{
		cp=(maxP-midP)*(toPos-0.5)/0.5+midP;
	}
	if (fromPos<=0.5)
	{
		cp2=(midP-minP)*fromPos/0.5+minP;
	}
	else
	{
		cp2=(maxP-midP)*(fromPos-0.5)/0.5+midP;
	}
	setPos(fromPos); // initialize servo at oscillation start position
	((cp-cp2)>0) ? deltaPos=1 : deltaPos=-1;
	updateInterval=fabs(time*1000/(cp-curPos)); // milliseconds between updates;
	if (updateInterval<20) // don't update faster than ~2 cycles of PWM signal
	{
		deltaPos*=20.0/updateInterval;
		updateInterval=20;
	}
	doneUpdates=0;
	lastUpdate=millis(); // get time hack to calculate elapsed time in millisecs
	cycling=1;
	sweepTime=time;
	cumPosition=(float)cp2; // float to accurately accumulate float position deltas
#ifdef DEBUG
	Serial.printf("Oscillate on for pin %d, deltaPos=%f, sweepTime=%f, updateInterval=%f, cycling=%d\n",servoPin,deltaPos,sweepTime,updateInterval,cycling);
#endif	
}
  
ESP8266Servo::ESP8266Servo(int pin) // initialize with 1000,1500,2000 as min,mid,max
{
	// initialize servo on pin with default min mid and max values
	servoPin=pin;
	minP=1000;
	midP=1500;
	maxP=2000;
	pinMode(dpins[pin],OUTPUT);
	analogWrite(servoPin,3276);
	pwmCount=3276;
	sweeping=0;
#ifdef DEBUG
	Serial.printf("Pwm on pin%d:%d, duration=3276\n",servoPin,dpins[servoPin]);
#endif
}
  
void ESP8266Servo::report()
{
	// Serial output of servo position information
  Serial.printf("curPos=%d minPos=%d midPos=%d maxPos=%d pin=%d:%d\n",curPos,minP,midP,maxP,dpins[servoPin],servoPin);
}

void ESP8266Servo::setPos(float Position)
{
	int cp;
	int pwmPeriod=1000000/pwmFreq;
	int duration;
	if (Position<=0.5)
	{
		// linear ramp between min and mid
		cp=(midP-minP)*Position/0.5+minP;
		duration=cp*pwmRange/pwmPeriod;
		analogWrite(dpins[servoPin],duration);
	}
	else
	{
		// linear ramp between mid and max
		cp=(maxP-midP)*(Position-0.5)/0.5+midP;
		duration=cp*pwmRange/pwmPeriod;
		pwmCount=duration;
		analogWrite(dpins[servoPin],duration);
	}
	pwmCount=duration; // update to allow positin interrogation
	curPos=cp;
	
#ifdef DEBUG
	Serial.printf("Pwm on pin%d, pulseWidth=%d curPos=%d\n",servoPin, cp, duration);
#endif	
}


void ESP8266Servo::setPwmFreq(float freq)
{
	// set pwm frequency for code to have accurate frequency/period info
	pwmFreq=freq;
}
 
void ESP8266Servo::sweep(float toPos,float duration)
{
	// sweep from current position to toPos over duration
	int cp;
	if (toPos<=0.5)
	{
		cp=(midP-minP)*toPos/0.5+minP;
	}
	else
	{
		cp=(maxP-midP)*(toPos-0.5)/0.5+midP;
	}
	((cp-curPos)>0) ? deltaPos=1 : deltaPos=-1;
	updateInterval=fabs(duration*1000/(cp-curPos)); // milliseconds between updates;
	if (updateInterval<20) // don't update faster than 2 cycles of PWM signal
	{
		deltaPos*=20.0/updateInterval;
		updateInterval=20;
	}
	doneUpdates=0;
	lastUpdate=millis();
	sweeping=1; // used to enable processing in sweepUdate
	sweepTime=duration;
	cumPosition=(float)curPos;
#ifdef DEBUG
	Serial.printf("Sweep on for pin %d, deltaPos=%f, sweepTime=%f, updateInterval=%f, sweeping=%d\n",servoPin,deltaPos,sweepTime,updateInterval,sweeping);
#endif	
}

/* the sweepUpdate function should be called in your loop function
* if you use the sweep function in your sketch
*******************************************************************/
void ESP8266Servo::sweepUpdate()
{
	// used in loop function to implement sweep updates
	if (!sweeping) return; // return if not sweeping
	int newPos,numDeltas;
	int duration;
	newPos=numDeltas=0;
	int cTime=millis(); // get current time
	int deltaTime=cTime-lastUpdate;
	if (deltaTime>=trunc(updateInterval)) // if update interval has passed do a position update
	{
		int pwmPeriod=1000000/pwmFreq;
		numDeltas=trunc(deltaTime/trunc(updateInterval));
		if (numDeltas==0) return;
		cumPosition=deltaPos*numDeltas + cumPosition;		
		duration=trunc(cumPosition*pwmRange/pwmPeriod+0.01);
		analogWrite(dpins[servoPin],duration);
		pwmCount=duration;
		newPos=trunc(cumPosition);
		lastUpdate=cTime; // set last update to now
		doneUpdates+=numDeltas;
		if (doneUpdates*updateInterval>=sweepTime*1000) sweeping=0;
		// time has elapsed stop sweeping
	}
#ifdef DEBUG
	if (numDeltas==1) Serial.printf("Sweeping on pin %d, NewPos=%d, duration=%d numDeltas=%d\n",servoPin,newPos,duration,numDeltas);
#endif	
}

/* the oscillateUpdate function should be called in your loop function
* if you use the oscillate function in your sketch
*******************************************************************/
void ESP8266Servo::oscillateUpdate()
{
	// used in loop function to do oscillate updates
	if (!cycling) return; // return if not cycling
	int newPos,numDeltas;
	int duration;
	newPos=numDeltas=0;
	int cTime=millis(); // get current time
	int deltaTime=cTime-lastUpdate;
	if (deltaTime>=trunc(updateInterval)) //  only process if delta time has passed
	{
		int pwmPeriod=1000000/pwmFreq;
		numDeltas=trunc(deltaTime/trunc(updateInterval));
		if (numDeltas==0) return;
		cumPosition=deltaPos*numDeltas + cumPosition;		
		duration=trunc(cumPosition*pwmRange/pwmPeriod+0.01);
		analogWrite(dpins[servoPin],duration);
		pwmCount=duration;
		newPos=trunc(cumPosition);
		lastUpdate=cTime;
		doneUpdates+=numDeltas;
		if (doneUpdates*updateInterval>=sweepTime*1000) 
		{
			// if an oscillate sequence time has expired sweep in oposite direction
			deltaPos*=-1;
			doneUpdates=0;
		}
	}
#ifdef DEBUG
	if (numDeltas==1) Serial.printf("Oscillating on pin %d, NewPos=%d, duration=%d numDeltas=%d time=%f\n",servoPin,newPos,duration,numDeltas,doneUpdates*updateInterval);
#endif	
}

