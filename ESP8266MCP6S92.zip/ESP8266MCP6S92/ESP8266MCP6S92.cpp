#include "ESP8266MCP6S92.h"
#include <SPI.h>

// define DEBUG to get verbose output on Serial Monitor
#define DEBUG

int gains[] = {1,2,4,5,8,10,16,32};
	
ESP8266MCP6S92::ESP8266MCP6S92(int cs)
{
  // initialize MCP6S92 Instance
  // set the slaveSelectPin as an output:
  slaveSelectPin=cs;
  pinMode(slaveSelectPin, OUTPUT);
  digitalWrite(slaveSelectPin,1);
  // initialize SPI:
  SPI.begin();
#ifdef DEBUG
	Serial.printf("MCP6S92 initialized\n");
#endif
}

void ESP8266MCP6S92::setChannel(int channel)
{
	byte cmd=0x41;
	byte value=channel;
	digitalWrite(slaveSelectPin, LOW);
	//  send in the address and value via SPI:
	SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
	SPI.transfer16(cmd*256+value);
	// take the SS pin high to de-select the chip:
	SPI.endTransaction();
	digitalWrite(slaveSelectPin, HIGH);
#ifdef DEBUG
	Serial.printf("Channel set to %d\n",channel);
#endif	
}

void ESP8266MCP6S92::setGain(int gain)
{
	byte cmd=0x40;
	byte value=gain && 0x007;
	digitalWrite(slaveSelectPin, LOW);
	//  send in the address and value via SPI:
	SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
	SPI.transfer16(cmd*256+value);
	// take the SS pin high to de-select the chip:
	SPI.endTransaction();
	digitalWrite(slaveSelectPin, HIGH);
#ifdef DEBUG
	Serial.printf("Gain parameter set to %d, which is a gain of %d\n",gain,gains[gain]);
#endif	
}
 
  
void ESP8266MCP6S92::shutdown()
{
	
	digitalWrite(slaveSelectPin, LOW);
	//  send in the address and value via SPI:
	SPI.transfer(0x20);
	SPI.transfer(0x00);
	// take the SS pin high to de-select the chip:
	digitalWrite(slaveSelectPin, HIGH);
#ifdef DEBUG
	Serial.printf("MCP6S92 shutdown\n");
#endif
}



