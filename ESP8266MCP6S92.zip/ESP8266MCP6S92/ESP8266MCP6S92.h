#ifndef ESP8266MCP6S92_h
#define ESP8266MCP6S92_h
#if (ARDUINO >= 100)
#include <Arduino.h>
#else
#include <WProgram.h>
#endif
class ESP8266MCP6S92
{
public:
	ESP8266MCP6S92(int cs);
	void setChannel(int channel); // channel either 0 or 1
	void setGain(int gain); // change to new gain
	void shutdown(); // put MCP6S92 in low power mode
	// either setGain or setChannel commands remove MCP6S92 from shutdown
private:
	int slaveSelectPin = D8;
};
#endif