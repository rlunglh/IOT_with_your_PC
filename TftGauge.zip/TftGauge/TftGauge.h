/* Hershey Fonts Render library

MIT license
written by Rick Lunglhofer
for Micro Image Systems

*/


#ifndef TftGauge_H
#define TftGauge_H
#include <TFT_eSPI.h>
#include <math.h>

#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

/*************************************************/
extern TFT_eSPI tft; 

class TftGauge {
public:
    
	TftGauge(float xc,float yc,float sang,float eang,float radius,float sval,float eval,int divisions,float increments,int color,char * fmt,char * valueFmt);
	void draw();
	void drawDanger(float sangle,float eangle,int color);
	void drawDangerByValue(float svalue,float evalue,int color);
	void setPosition(float value);
private:
	void drawValue(float value,int hcolor,int vcolor,int erase);
	void drawHand(float value,int hcolor,int erase);
	float gx,gy,gsang,geang,gsval,geval,gradius,oldPos=-10000.0;
	char buf[21];
	int gcolor,gdivisions;
	char * vfmt;
	char * valFmt;
	float oldvalue[2],gposition=-10000.0;
	float gincrements,oldx[2],oldy[2];
	float pi=3.14159;
};

class TftVbarGraph {
public:
    
	TftVbarGraph(float x,float y,int width,int height,float sval,float eval,int divisions,float increments,int color,char * fmt,char * valueFmt);
	void draw();
	void setPosition(float value);
private:
	void drawValue(float value,int hcolor,int vcolor,int erase);
	void drawBar(float value,int hcolor,int erase);
	float gx,gy,gsval,geval,oldPos=-10000.0;
	char buf[21];
	int gcolor,gdivisions,gwidth,gheight;
	char * vfmt;
	char * valFmt;
	float oldvalue[2],gposition=-10000.0;
	float gincrements,oldx[2],oldy[2];
	float pi=3.14159;
};

class TftHbarGraph {
public:
    
	TftHbarGraph(float x,float y,int width,int height,float sval,float eval,int divisions,float increments,int color,char * fmt,char * valueFmt);
	void draw();
	void setPosition(float value);
private:
	void drawValue(float value,int hcolor,int vcolor,int erase);
	void drawBar(float value,int hcolor,int erase);
	float gx,gy,gsval,geval,oldPos=-10000.0;
	char buf[21];
	int gcolor,gdivisions,gwidth,gheight;
	char * vfmt;
	char * valFmt;
	float oldvalue[2],gposition=-10000.0;
	float gincrements,oldx[2],oldy[2];
	float pi=3.14159;
};
#endif
