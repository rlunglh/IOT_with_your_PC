/* TftGauge library

MIT license
written by Rick Lunglhofer
for Micro Image Systems

*/

#include "TftGauge.h"
#include <math.h>
#ifndef ESP32
#include <TFT_eSPI.h> // Hardware-specific library#else
#include <TFT_eSPI_ESP32.h> // Hardware-specific library
#endif
extern TFT_eSPI tft;

TftGauge::TftGauge(float xc,float yc,float sang,float eang,float radius,float sval,float eval,int divisions,float increments,int color,char * fmt,char * valueFmt)
{
	Serial.printf("Entered TftGuage\n");
	Serial.printf("sval=%f eval=%f sang=%f eang=%f\n",sval,eval,sang,eang);
    gx=xc; gy=yc; gsang=sang; geang=eang; gradius=radius; gsval=sval; geval=eval; gcolor=color;vfmt=fmt,valFmt=valueFmt;oldPos=-10000;
	gincrements=increments;gdivisions=divisions;
	oldx[0]=-10000.0;
	oldy[0]=-10000.0;
	oldx[1]=-10000.0;
	oldy[1]=-10000.0;
	oldvalue[0]=oldvalue[1]=-10000.0;
}

void TftGauge::draw()
{
	oldPos=-10000.0;
	float sAngle=atan(0.9/gradius)*180/pi; 
	for (int i=0;(i*sAngle+gsang)<geang;i++) tft.drawPixel(gx+gradius*sin((gsang+i*sAngle)*pi/180),gy-gradius*cos((gsang+i*sAngle)*pi/180),gcolor);
	tft.fillCircle(gx,gy,3,gcolor);
	float sval=gsval;
	float xoff=0,yoff=0;
	float a=gsang;float svalt=gsval;
	float anginc=(geang-gsang)/gdivisions;
	for ( int i=0;i<=gdivisions;i++)
	{
	tft.drawLine(gx+sin(a*pi/180)*gradius*0.9,gy-cos(a*pi/180)*0.9*gradius,gx+sin(a*pi/180)*gradius*1.05,gy-cos(a*pi/180)*gradius*1.05,0xf100);
	float s180=sin(a*pi/180)*gradius*0.9;float c180=cos(a*pi/180)*gradius*0.9;
	sprintf((char *)&buf,vfmt,sval);
	if (s180< 0.0)  xoff=-9;
	if (c180< 0.0) yoff=+7;
	if (c180<0.1 && c180 >-0.1) yoff=5;
	if (s180<0.1 && s180 >-0.1) xoff=-6;    
	tft.setTextColor(0xffff);tft.setTextSize(1);
	tft.setCursor(-5+gx+xoff+1.11*s180/0.9,gy-yoff-1.11*c180/0.9);
	tft.print((char *)buf);
	sval+=(geval-svalt)/gdivisions;
	a+=anginc;
	xoff=yoff=0;
	}
	int incrs=abs(geval-svalt)/gincrements;
	a=gsang;
	for (int i=0;i<=incrs;i++)
	{
		float s180=sin(a*pi/180)*gradius*0.95,c180=cos(a*pi/180)*gradius*0.95;
		tft.drawLine(gx+s180,gy-c180,gx+s180/0.95,gy-c180/0.95,0xf100);
		a+=(geang-gsang)/incrs;
	}	oldx[0]=-10000.0;
	oldy[0]=-10000.0;
	oldx[1]=-10000.0;
	oldy[1]=-10000.0;
	oldvalue[0]=oldvalue[1]=-10000.0;
}

void TftGauge::drawDanger(float sangle,float eangle,int color)
{
	float sAngle=atan(0.7071/gradius)*90/pi; 
	for (int i=0;(i*sAngle+sangle)<eangle;i++) tft.drawLine(gx+gradius*1.015*sin((sangle+i*sAngle)*pi/180),gy-gradius*1.015*cos((sangle+i*sAngle)*pi/180),
		gx+gradius*0.98*sin((sangle+i*sAngle)*pi/180),gy-gradius*0.98*cos((sangle+i*sAngle)*pi/180),
		color);
}
void TftGauge::drawDangerByValue(float svalue,float evalue,int color)
{
	float sAngle=atan(0.7071/gradius)*90/pi; 
	float sangle,eangle;
	sangle=(svalue-gsval)/(geval-gsval)*(geang-gsang)+gsang;
	eangle=(evalue-gsval)/(geval-gsval)*(geang-gsang)+gsang;	
	for (int i=0;(i*sAngle+sangle)<eangle;i++) tft.drawLine(gx+gradius*1.015*sin((sangle+i*sAngle)*pi/180),gy-gradius*1.015*cos((sangle+i*sAngle)*pi/180),
		gx+gradius*0.98*sin((sangle+i*sAngle)*pi/180),gy-gradius*0.98*cos((sangle+i*sAngle)*pi/180),
		color);
	
}
void TftGauge::drawHand(float value,int hcolor,int erase)
{
	float angle;	
	angle=(value-gsval)/(geval-gsval)*(geang-gsang)+gsang;
	if (angle>360.0) angle-=360.0;
	float xend,yend;
	xend=gx+(gradius-8)*sin(angle*pi/180);
	yend=gy-(gradius-8)*cos(angle*pi/180);
	if (oldx[erase]!=xend  || oldy[erase]!=yend)
	{
		if ((angle>=45.0 && angle<=135.0) || (angle>=225.0 && angle<=315.0)) tft.fillTriangle(gx, gy+3, xend, yend,gx,gy-3,hcolor);  
		else tft.fillTriangle(gx-3, gy, xend, yend,gx+3,gy,hcolor);
		if (!erase) tft.fillCircle(gx,gy,3,gcolor);
		oldx[erase]=xend;
		oldy[erase]=yend;
		if (!erase) oldPos=value;
		oldvalue[erase]=value;
	}	
}  

void TftGauge::drawValue(float value,int hcolor,int vcolor,int erase)
{
	int xoff,yoff;
	char buf2[20];
	sprintf((char *)buf,valFmt,value);
	sprintf((char *)buf2,valFmt,oldvalue[erase]);
	if (strcmp((char *)&buf,(char *)&buf2)==0 && strstr(valFmt,"%") != 0) return;
	int csize=strlen((char *)&buf);
	int cangle=gsang+(geang-gsang)/2; while (cangle>=360) cangle-=360;
	if ((cangle+360)>=(360-45) && cangle<=45) 
	{  xoff=0;yoff=-gradius/2;} 
	if (cangle>45 && cangle<=135) 
	{  xoff=gradius/2;yoff=0;} 
	if (cangle>135 && cangle<=225) 
	{  xoff=0;yoff=gradius/2;} 
	if (cangle>225 && cangle<(315)) 
	{  xoff=-gradius/2;yoff=0;} 
	xoff-=csize*4;
	tft.setTextColor(vcolor,0);tft.setTextSize(2);tft.setCursor(gx+xoff,gy+yoff);tft.print((char *)buf);tft.setTextColor(0xffff);
	tft.fillCircle(gx,gy,4,0xf100);tft.setTextSize(1);
}  

void TftGauge::setPosition(float value)
{
	if (gposition==value) return;
	gposition=value;
	if (oldPos!=-10000.0 && oldPos!=value) 
	{
		if (strstr(valFmt,"%") != 0) drawValue(oldPos,0,0,1);
		drawHand(oldPos,0,1);
	}
	if (oldvalue[0]!=value) drawValue(value,0xf100,0xffff,0);
	if (oldvalue[0]!=value) drawHand(value,0xf100,0);
}

TftVbarGraph::TftVbarGraph(float x,float y,int width,int height,float sval,float eval,int divisions,float increments,int color,char * fmt,char * valueFmt)
{
	Serial.printf("Entered TftVbarGraph\n");
    gx=x; gy=y; gwidth=width; gheight=height; gsval=sval; geval=eval; gcolor=color;vfmt=fmt,valFmt=valueFmt;oldPos=-10000;
	gincrements=increments;gdivisions=divisions;
	oldx[0]=-10000.0;
	oldy[0]=-10000.0;
	oldx[1]=-10000.0;
	oldy[1]=-10000.0;
	oldvalue[0]=oldvalue[1]=-10000.0;
}

void TftVbarGraph::draw()
{
	oldPos=-10000.0;
	tft.drawRect(gx,gy,gwidth,gheight+1,gcolor);
	float inc=gheight*1.0/gdivisions;
	float vinc=(geval-gsval)/gdivisions;
	tft.setTextSize(1);tft.setTextColor(0xffff,0);
	for ( int i=0;i<=gdivisions;i++)
	{
		tft.drawLine(gx,gy+gheight-i*inc,gx+gwidth+4,gy+gheight-i*inc,gcolor);
		tft.setCursor(gx+gwidth+8,gy+gheight-i*inc-3);
		sprintf((char *)&buf,vfmt,gsval+i*vinc);
		tft.print((char *)&buf);
	}
	int incrs=abs(geval-gsval)/gincrements;
	for (int i=0;i<=incrs;i++)
	{
		tft.drawLine(gx,gy+i*gheight/incrs,gx+gwidth+2,gy+i*gheight/incrs,gcolor);
	}
}

void TftVbarGraph::drawBar(float value,int hcolor,int erase)
{
	int barHeight=(value-gsval)/(geval-gsval)*gheight;
	int bary=gy+gheight-barHeight;
	tft.fillRect(gx,bary,gwidth-1,barHeight,hcolor);
	if (!erase) oldPos=value;
}  

void TftVbarGraph::drawValue(float value,int hcolor,int vcolor,int erase)
{
	tft.setTextSize(2);tft.setCursor(gx-12,gy-19);tft.setTextColor(0xffff,0);
	sprintf((char *)&buf,valFmt,value);
	tft.print((char *)&buf);
}  

void TftVbarGraph::setPosition(float value)
{
	if (gposition==value) return;
	gposition=value;
	if (oldPos!=-10000.0 && oldPos!=value) 
	{
		if (strstr(valFmt,"%") != 0) drawValue(oldPos,0,0,1);
		drawBar(oldPos,0,1);
	}
	if (oldvalue[0]!=value) drawValue(value,0xf100,0xffff,0);
	if (oldvalue[0]!=value) drawBar(value,0xf100,0);
}

TftHbarGraph::TftHbarGraph(float x,float y,int width,int height,float sval,float eval,int divisions,float increments,int color,char * fmt,char * valueFmt)
{
	Serial.printf("Entered TftVbarGraph\n");
    gx=x; gy=y; gwidth=width; gheight=height; gsval=sval; geval=eval; gcolor=color;vfmt=fmt,valFmt=valueFmt;oldPos=-10000;
	gincrements=increments;gdivisions=divisions;
	oldx[0]=-10000.0;
	oldy[0]=-10000.0;
	oldx[1]=-10000.0;
	oldy[1]=-10000.0;
	oldvalue[0]=oldvalue[1]=-10000.0;
}

void TftHbarGraph::draw()
{
	oldPos=-10000.0;
	tft.drawRect(gx,gy,gwidth,gheight+1,gcolor);
	float inc=gwidth*1.0/gdivisions;
	float vinc=(geval-gsval)/gdivisions;
	tft.setTextSize(1);tft.setTextColor(0xffff,0);
	for ( int i=0;i<=gdivisions;i++)
	{
		tft.drawLine(gx+i*inc,gy,gx+i*inc,gy+gheight+7,gcolor);
		tft.setCursor(gx+i*inc-8,gy+gheight+10);
		sprintf((char *)&buf,vfmt,gsval+i*vinc);
		tft.print((char *)&buf);
	}
	int incrs=abs(geval-gsval)/gincrements;
	for (int i=0;i<=incrs;i++)
	{
		tft.drawLine(gx+i*gwidth/incrs,gy,gx+i*gwidth/incrs,gy+gheight+4,gcolor);
	}
}

void TftHbarGraph::drawBar(float value,int hcolor,int erase)
{
	int barWidth=(value-gsval)/(geval-gsval)*gwidth;
	tft.fillRect(gx,gy,barWidth,gheight,hcolor);
	if (!erase) oldPos=value;
}  

void TftHbarGraph::drawValue(float value,int hcolor,int vcolor,int erase)
{
	tft.setTextSize(2);tft.setCursor(gx+gwidth+4,gy+gheight/2-4);tft.setTextColor(0xffff,0);
	sprintf((char *)&buf,valFmt,value);
	tft.print((char *)&buf);
}  

void TftHbarGraph::setPosition(float value)
{
	if (gposition==value) return;
	gposition=value;
	if (oldPos!=-10000.0 && oldPos!=value) 
	{
		if (strstr(valFmt,"%") != 0) drawValue(oldPos,0,0,1);
		drawBar(oldPos,0,1);
	}
	if (oldvalue[0]!=value) drawValue(value,0xf100,0xffff,0);
	if (oldvalue[0]!=value) drawBar(value,0xf100,0);
}
