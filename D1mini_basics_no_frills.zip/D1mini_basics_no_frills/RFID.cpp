//#define RFID
#ifdef RFID
//#define TFT
#ifdef TFT
#include <TFT_eSPI.h> // Hardware-specific library
extern TFT_eSPI tft;
void drawJpeg(const char *filename, int xpos, int ypos);
#include <Hershey.h>
extern Hershey HF;
#endif

long rfidTicks=0;
byte newLockState=-2;
boolean match = false;          // initialize card match to false
extern boolean programMode;  // initialize programming mode to false
boolean replaceMaster = false;

// define SELECTS if you want to have the names associated with the tags displayed
//#define SELECTS
#include <MFRC522.h>  // Library for Mifare RC522 Devices
extern MFRC522 nfc;

#define FS_NO_GLOBALS
#include <FS.h>
void rfidShowStatus();
extern byte rfidLock;
extern char nD[];
extern int indx;
extern char buf[641];
// functions from D1mini_basics
void doQuery(char * query);
void getname(char  * cardid,char * firstname,char * lastname);

// defines here rather than in a header file
boolean findID( byte find[] );
void successWrite();
void failedWrite();
uint8_t findIDSLOT( byte find[] );
void successDelete();
void failedDelete();



uint8_t successRead;    // Variable integer to keep if we have Successful Read from Reader
uint8_t ncards=0;
byte storedCard[4];   // Stores an ID read from File
byte readCard[4];   // Stores scanned ID read from RFID Module
byte masterCard[4];   // Stores master card's ID read from File

#define redLed -1   // Set Led Pins
#define greenLed -1
#define blueLed -1

#define relay -1    // Set Relay Pin
uint8_t cards[60][4];
//#define COMMON_ANODE

#ifdef COMMON_ANODE
#define LED_ON LOW
#define LED_OFF HIGH
#else
#define LED_ON HIGH
#define LED_OFF LOW
#endif

uint8_t cHex(uint16_t in)
{
  byte val1,val2;
  val1=in&0xff00;
  val2=in&0x00ff;
  if (val1<58*16) val1-=48*16;
  else val1-=55*16;
  if (val2<58) val2-=48;
  else val2-=55;
  return val1+val2;
}

void printFile()
{
  fs::File fin=SPIFFS.open("/locked/RFIDcard","r");
  uint8_t num,magic,val;
  int card;
  fin.read(&num,1);
  fin.read(&magic,1);
  fin.read(&val,1);fin.read(&val,1); // skip cr lf
  Serial.printf("\n\n%c%c\n",num,magic);
  int i;
  num -= 'A';
  ncards=num;
  uint8_t inHex;
  byte valc;
  for (i=0;i<num;i++) {
  for (indx=0;indx<4;indx++) {fin.read((uint8_t *)&valc,1); inHex=16*cHex(valc);
  fin.read((uint8_t *)&valc,1); inHex+=cHex(valc);
 // Serial.printf("inHex %X \n",inHex);
  cards[i][indx]=inHex;Serial.print(cards[i][indx], HEX);
  if (i==0) masterCard[indx]=cards[i][indx];}
  fin.read(&val,1);fin.read(&val,1); Serial.println();yield(); }  // skip cr lf
  fin.close();
  Serial.println("Master Card's UID");
  Serial.printf("%X%X%X%X\n",masterCard[0],masterCard[1],masterCard[2],masterCard[3]);
}
void dumpFile()
{
  fs::File fin=SPIFFS.open("/locked/RFIDcard","w");
  uint8_t val=ncards+'A';
  uint8_t cr=0x0d,lf=0x0a;
  Serial.printf("ncards=%d\n",ncards);
  fin.write(val);
  val='X';fin.write(val);
  fin.write(cr);fin.write(lf);
  int i;
  char outHex[3];outHex[2]=0;
  for (i=0;i<ncards;i++)
  { 
    for (indx=0;indx<4;indx++)  
    {
      Serial.printf("%X",cards[i][indx]);
      sprintf((char *)&outHex,"%02X",cards[i][indx]);fin.write((uint8_t *)&outHex[0],1);fin.write((uint8_t *)&outHex[1],1);
    }
    Serial.println();fin.write(cr);fin.write(lf);
  }
  fin.close();
}
// selayTick sets rfidTicks and newLockState
void delayTick(long ticks,byte lockState)
{
  rfidTicks=ticks;
  newLockState=lockState;
}

/////////////////////////////////////////  Access Granted    ///////////////////////////////////
void granted ( uint16_t setDelay) {
 // digitalWrite(blueLed, LED_OFF);   // Turn off blue LED
 // digitalWrite(redLed, LED_OFF);  // Turn off red LED
 // digitalWrite(greenLed, LED_ON);   // Turn on green LED
 // digitalWrite(relay, LOW);     // Unlock door!
  delayTick(6000/50,1);          // Hold door lock open for given seconds
}

///////////////////////////////////////// Access Denied  ///////////////////////////////////
void denied() {
//  digitalWrite(greenLed, LED_OFF);  // Make sure green LED is off
//  digitalWrite(blueLed, LED_OFF);   // Make sure blue LED is off
//  digitalWrite(redLed, LED_ON);   // Turn on red LED

  delayTick(3000/50,1);
}


///////////////////////////////////////// Get PICC's UID ///////////////////////////////////
uint8_t getID() {
  byte data[10],serial[5];
  byte status = nfc.requestTag(MF1_REQIDL, data);
  if (status == MI_OK) {
    Serial.println("Tag detected.");
    Serial.print("Type: ");
    Serial.print(data[0], HEX);
    Serial.print(", ");
    Serial.println(data[1], HEX);

    // calculate the anti-collision value for the currently detected
    // tag and write the serial into the data array.
    status = nfc.antiCollision(data);
    memcpy(serial, data, 5);
 while (status==MI_OK) {yield();status=nfc.requestTag(MF1_REQIDL, data);}
 Serial.println(F("Scanned PICC's UID:"));
  for ( uint8_t i = 0; i < 4; i++) {  //
    readCard[i] = serial[i];
    Serial.print(readCard[i], HEX);
  }
  Serial.println("");
  return 1;
  }
  return 0;
}



///////////////////////////////////////// Cycle Leds (Program Mode) ///////////////////////////////////
void cycleLeds() {
  programMode=1;
  rfidShowStatus();
}

//////////////////////////////////////// Normal Mode Led  ///////////////////////////////////
void normalModeOn () {
  programMode=0;
  drawJpeg("/padlock.jpg",22,103);
    HF.drawStringOpaque(154,190,1.0,0x0,0xffff,    "          ");
  rfidShowStatus();
}

//////////////////////////////////////// Read an ID from File //////////////////////////////
void readID( uint8_t number ) {
  for (indx=0;indx<4;indx++) storedCard[indx]=cards[number][indx];
}


///////////////////////////////////////// Add ID to File   ///////////////////////////////////
void writeID() {
  if ( !findID( readCard ) ) {     // Before we write to the file, check to see if we have seen this card before!
    for (indx=0;indx<4;indx++) {cards[ncards][indx]=readCard[indx];Serial.printf("%x",readCard[indx]);}
    ncards++;
    HF.drawStringOpaque(154,190,1.0,0x0,0xffff,    "Added   ");
    dumpFile();
    printFile();
    successWrite();
  }
  else {
    failedWrite();
    Serial.println(F("Failed! There is something wrong with ID or bad File"));
  }
}

///////////////////////////////////////// Remove ID from File   ///////////////////////////////////
void deleteID( byte a[] ) {
  if ( !findID( a ) ) {     // Before we delete from the File, check to see if we have this card!
    failedWrite();      // If not
    Serial.println(F("Failed! There is something wrong with ID or bad File"));
  }
  else {
     uint8_t num;
   num=ncards;   // Get the numer of used spaces, position 0 stores the number of ID cards
    uint8_t slot;       // Figure out the slot number of the card
    uint8_t start;      // = ( num * 4 ) + 6; // Figure out where the next slot starts
    uint8_t looping;    // The number of times the loop repeats
    uint8_t j;
    uint8_t count = num; // Read the first Byte of File that stores number of cards
    slot = findIDSLOT( a );   // Figure out the slot number of the card to delete
   // Serial.printf("Found card at slot %d\n",slot);
    if (slot!=0xff)
    {
      for (indx=slot;indx<ncards;indx++)
      {
       for (j=0;j<4;j++) cards[indx][j]=cards[indx+1][j];
      }
      ncards--;
    }
    
    HF.drawStringOpaque(154,190,1.0,0x0,0xffff,    "Removed");
    dumpFile();
    printFile();
    successDelete();
    Serial.println(F("Succesfully removed ID record"));
  }
}

///////////////////////////////////////// Check Bytes   ///////////////////////////////////
boolean checkTwo ( byte a[], byte b[] ) {
  if ( a[0] == 0 ) return false;      // Make sure there is something in the array first
  for ( uint8_t k = 0; k < 4; k++ ) {   // Loop 4 times
 //   Serial.print(a[k], HEX);Serial.print(" "); Serial.println(b[k], HEX);
    if (  a[k] != b[k] )     // IF a != b then set match = false, one fails, all fail
      return false;
  }
  return true;
}

///////////////////////////////////////// Find Slot   ///////////////////////////////////
uint8_t findIDSLOT( byte find[] ) {
  uint8_t count;
  count=ncards; 
  for ( uint8_t i = 1; i <= count; i++ ) {    // Loop once for each File entry
    readID(i);                // Read an ID from File, it is stored in storedCard[4]
    if ( checkTwo( find, storedCard ) ) {   // Check to see if the storedCard read from File
      // is the same as the find[] ID card passed
      return i;         // The slot number of the card
      break;          // Stop looking we found it
    }
  }
  return 0xff;
}

///////////////////////////////////////// Find ID From File   ///////////////////////////////////
boolean findID( byte find[] ) {
  Serial.printf("finding... %X%X%X%X within %d card(s)\n",find[0],find[1],find[2],find[3],ncards-1);
  for ( uint8_t i = 1; i < ncards; i++ ) {    // Loop once for each File entry
    for (indx=0;indx<4;indx++) storedCard[indx]=(byte)cards[i][indx]; 
  //Serial.printf("storedCard... %d %X%X%X%X\n",i,storedCard[0],storedCard[1],storedCard[2],storedCard[3]);
    if ( checkTwo( find, storedCard ) ) {   // Check to see if the storedCard read from File
      return true;
      break;  // Stop looking we found it
    }
  }
 //Serial.println("Card not Found!");
  return false;
}

///////////////////////////////////////// Write Success to File   ///////////////////////////////////
// Flashes the green LED 3 times to indicate a successful write to File
void successWrite() {
  Serial.println("Write Success");
}

///////////////////////////////////////// Write Failed to File   ///////////////////////////////////
// Flashes the red LED 3 times to indicate a failed write to File
void failedWrite() {
  Serial.println("Write Failed");

}

///////////////////////////////////////// Success Remove UID From File  ///////////////////////////////////
// Flashes the blue LED 3 times to indicate a success delete to File
void successDelete() {
Serial.println("Successful Delete");
}

////////////////////// Check readCard IF is masterCard   ///////////////////////////////////
// Check to see if the ID passed is the master programing card
boolean isMaster( byte test[] ) {
  Serial.println("In isMaster");
  if ( checkTwo( test, masterCard ) )
    return true;
  else
    return false;
}

// define RESET to create new RFIDcard file
//#define RESET
extern int Count;

void RFIDloop()
{
  if (Count%5==0)
  {
   successRead = getID();  // sets successRead to 1 when we get read from reader otherwise 0
    yield();
    if (programMode) {
      cycleLeds();              
    }
    else {
      normalModeOn();     // Normal mode, blue Power LED is on, all others are off
    }
  }
  //while (!successRead);   //the program will not go further while you are not getting a successful read
  if (programMode && successRead) {
    if ( isMaster(readCard) ) { //When in program mode check First If master card scanned again to exit program mode
      while (getID());
      Serial.println(F("Master Card Scanned"));
      Serial.println(F("Exiting Program Mode"));
      Serial.println(F("-----------------------------"));
      // print file contents
      programMode=0;
      printFile();
      normalModeOn();
      return;
    }
    else if (successRead) {
      while (getID());
      if (  findID(readCard) ) { // If scanned card is known delete it
        Serial.println(F("I know this PICC, removing..."));
        deleteID(readCard);
        sprintf((char *)&buf,"insert into usr.dooraccess values('%X%X%X%X',4,now(),'%s')",
            readCard[0],readCard[1],readCard[2],readCard[3],(char *)nD);
            doQuery((char *)&buf);
        Serial.println("-----------------------------");
        Serial.println(F("Scan a PICC to ADD or REMOVE from File"));
      }
      else {                    // If scanned card is not known add it
        Serial.println(F("I do not know this PICC, adding..."));
        Serial.print("CardID -> ");for (indx=0;indx<4;indx++) Serial.printf("%x",readCard[indx]);Serial.println();
        writeID();        
        sprintf((char *)&buf,"insert into usr.dooraccess values('%X%X%X%X',3,now(),'%s')",
            readCard[0],readCard[1],readCard[2],readCard[3],(char *)nD);
            doQuery((char *)&buf);
        Serial.println(F("-----------------------------"));
        Serial.println(F("Scan a PICC to ADD or REMOVE to File"));
      }
    }
  }
  else if (successRead) {
    if ( isMaster(readCard)) {    // If scanned card's ID matches Master Card's ID - enter program mode
      programMode = 1;
      while (getID());
      Serial.println(F("Hello Master - Entered Program Mode"));
      fs::File fin=SPIFFS.open("/locked/RFIDcard","r");
      uint8_t count;fin.read((uint8_t *)&count,1);  
      ncards=count-'A';
      fin.close();
      Serial.print(F("I have "));     
      Serial.print(ncards);
      Serial.print(F(" record(s) on File"));
      Serial.println("");
      Serial.println(F("Scan a PICC to ADD or REMOVE to File"));
      Serial.println(F("Scan Master Card again to Exit Program Mode"));
      Serial.println(F("-----------------------------"));
    }
    else {
      if ( findID(readCard) ) { // If not, see if the card is in the File
        char first[32];
        char last[32];
        char cardID[10];
        rfidLock=0;
        sprintf((char *)cardID,"%X%X%X%X",readCard[0],readCard[1],readCard[2],readCard[3]);
#ifdef TFT        
    //    drawJpeg("/lockopen.jpg",22,103);
#endif
      //  HF.drawStringOpaque(154,129,1.0,0xffff,0x03e0,    "UNLOCKED");
//        digitalWrite(greenLed,LED_ON);
//        digitalWrite(blueLed,LED_OFF);
#ifdef SELECTS
        getname((char *)&cardID,(char *)&first,(char *)&last);
        yield();
        Serial.printf("Welcome, %s %s identified by %X%X%X%X shall pass\n",(char *)&first,(char *)&last,readCard[0],readCard[1],readCard[2],readCard[3]);
#else
        yield();
        Serial.printf("Welcome, Tag %X%X%X%X is Authorized and shall pass\n",readCard[0],readCard[1],readCard[2],readCard[3]);
#endif        
        
        sprintf((char *)&buf,"insert into usr.dooraccess values ('%X%X%X%X',1,now(),'%s')",readCard[0],readCard[1],readCard[2],readCard[3],(char *)nD);
        Serial.println((char *)&buf);
        doQuery((char *)&buf);
        delayTick(8000/50,1);       // Open the door lock for 3000 ms
      }
      else {      // If not, show that the ID was not valid
        rfidLock=-1;
#ifdef TFT
        drawJpeg("/denylock.jpg",22,103); drawJpeg("/rfidr.jpg",10,2);
        HF.drawStringOpaque(154,129,1.0,0xffff,0xf100,    "  DENIED ");
#endif
        Serial.printf("Read Unknown Token %X%X%X%X\nYou shall not pass!\n",readCard[0],readCard[1],readCard[2],readCard[3]);
        sprintf((char *)&buf,"insert into usr.dooraccess values ('%X%X%X%X',0,now(),'%s')",readCard[0],readCard[1],readCard[2],readCard[3],(char *)nD);
        doQuery((char *)&buf);
        Serial.printf("Read Unknown Token %X%X%X%X\nYou shall not pass!\n",readCard[0],readCard[1],readCard[2],readCard[3]);
        sprintf((char *)&buf,"insert into usr.dooraccess values ('%X%X%X%X',0,now(),'%s')",readCard[0],readCard[1],readCard[2],readCard[3],(char *)nD);
        doQuery((char *)&buf);
        delayTick(4000/50,1);
      }
    }
  }
}


void RFIDsetup()
{ 
yield();
  uint8_t val=0;
#ifdef RESET
  fs::File frs=SPIFFS.open("/locked/RFIDcard","w");
  frs.write(val);
  frs.write(val);frs.write(13);frs.write(10);
  frs.close();
#endif
  // Check if master card defined, if not let user choose a master card
  if (!SPIFFS.exists("/locked/RFIDcard"))
  {
    fs::File fin=SPIFFS.open("/locked/RFIDcard","w");
    uint8_t val=0;
    fin.write(val);
    val='A';
    fin.write(val);
    fin.close();
    ncards=0;
  }
  fs::File fin=SPIFFS.open("/locked/RFIDcard","r");
  uint8_t magic;
  fin.read(&magic,1);fin.read(&magic,1);
  fin.close();
  if (magic != 'X') {
    Serial.println(F("No Master Card Defined"));
    Serial.println(F("Scan A PICC to Define as Master Card"));
    do {
      successRead = getID();            // sets successRead to 1 when we get read from reader otherwise 0
      yield();
    }
    while (!successRead);                  // Program will not go further while not a successful read
    Serial.println("Master card read");
    fs::File fi=SPIFFS.open("/locked/RFIDcard","w");
    uint8_t val='A'+1;ncards=0;
    fi.write((uint8_t *)&val,1);
    val='X';
    fi.write((uint8_t *)&val,1);fi.write(13);fi.write(10);
    char outHex[3];outHex[2]=0;
    for (indx=0;indx<4;indx++) 
    {
      Serial.print(readCard[indx], HEX);
      masterCard[indx]=readCard[indx];
      cards[0][indx]=readCard[indx];
    }
    ncards=1;
    dumpFile();
    Serial.println(F("Master Card Defined"));
  }
  Serial.println("");
  Serial.println(F("-------------------"));
  Serial.println(F("Everything is ready"));
  printFile();
  Serial.println(F("Waiting PICCs to be scanned"));
}
#endif
