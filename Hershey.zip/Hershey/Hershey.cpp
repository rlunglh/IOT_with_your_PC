/* Hershey Fonts Render library

MIT license
written by Rick Lunglhofer
for Micro Image Systems

*/

#include "Hershey.h"
#include <math.h>
#include <TFT_eSPI.h> // Hardware-specific library

extern TFT_eSPI tft;

Hershey::Hershey(char * defaultFont)
{
	deltax=0;deltay=0;
	if (strlen(defaultFont)==0) return;
	setFont(defaultFont);
}

void Hershey::loadfile(char * fname)
{
	int i;	
	if (!SPIFFS.exists(fname)) {Serial.print(fname);Serial.println(" Does not exist");}
    File fin=SPIFFS.open(fname,"r");
	int cc=0;
	for (i=0;i<96;i++)
	{
		// iterate through file lines and store offset into hFont[]
		hFont[i]=cc;
		byte done=0;char c;
		while (done==0) 
		{
			fin.readBytes(&c,1);
			cc++;
			//Serial.print(c);
			if (c==10) done=1;
		}
		delay(1);
		//Serial.print("\n char ");//Serial.printf("%d .%c. finished\n",i,i+' ');
	}
	fin.close();
    strcpy((char *)&fontFile,fname);
}
	//Serial.printf("Done processing %s\n",(char *)&fontFile);
    //Serial.println("leaving loadfile");

void Hershey::setFont(char * font)
{
//	Serial.println("Entering setFont");
	//Serial.println(font);
	int i;
	char fname[32];
    if (strstr(font,"serif")!=0) // Serif Font
	{
		if (strcmp((char *)&fontFile,"/ltr.hrsh")==0) return;
		if (!SPIFFS.exists("/ltr.hrsh")) { Serial.println("File missing");return;}
	  loadfile("/ltr.hrsh");
//	Serial.println("Leaving setFont with serif");
	  return;
	} 
    if (strstr(font,"sansbold")!=0) // Sans Font Bold
	{
		if (strcmp((char *)&fontFile,"/futuram.hrsh")==0) return;
		if (!SPIFFS.exists("/futuram.hrsh")) { Serial.println("File missing");return;}
	  loadfile("/futuram.hrsh");
	//Serial.println("Leaving setFont with sansbold");
	  return;
	}	 
    if (strstr(font,"sans")!=0) // Sans Font
    {
		if (strcmp((char *)&fontFile,"/futural.hrsh")==0) return;
		if (!SPIFFS.exists("/futural.hrsh")) { Serial.println("File missing");return;}
	  loadfile("/futural.hrsh");
	//Serial.println("Leaving setFont with sans");
		return;
	}	 
    if (strstr(font,"greek")!=0) // Greek Font
    {
		if (strcmp((char *)&fontFile,"/greek.hrsh")==0) return;
		if (!SPIFFS.exists("/greek.hrsh")) { Serial.println("File missing");return;}
	  loadfile("/greek.hrsh");
	//Serial.println("Leaving setFont with greek");
		return;
	}	 
    if (strstr(font,"cursive")!=0) // Cursive Font
    {
		if (strcmp((char *)&fontFile,"/cursive.hrsh")==0) return;
		if (!SPIFFS.exists("/cursive.hrsh")) { Serial.println("File missing");return;}
	  loadfile("/cursive.hrsh");
	//Serial.println("Leaving setFont with cursive");
		return;
	}
}

void Hershey::setCursor(int x,int y) {ox=x;oy=y;}

void Hershey::drawStringRotated(int x,int y,int r,float scale,int color,float a,char * string)
{
  int xc,yc;
  float sina,cosa,sinr,cosr;
  sina=sin(a/360.0*2*3.14159);cosa=cos(a/360.0*2*3.14159);
  sinr=sin((a-90)/360.0*2*3.14159);cosr=cos((a-90)/360.0*2*3.14159);
  deltax=14*cosr*(strlen(string)-0.5);deltay=14*sinr*(strlen(string)-0.5);
  xc=x +r*sinr-deltax;
  yc=y- r*cosr-deltay; 
  int i;
  deltax=0;deltay=0;
  for (i=0;i<strlen(string);i++) {yield();/*//Serial.println(*(string+i));*/drawRotated(xc,yc,*(string+i),scale,color,a);}
}

void Hershey::drawString(int x,int y,float scale,int color,char * string)
{
  ox=x;oy=y;
  int i;
  //Serial.printf("Entered drawStrig with string %s\n",string);
  for (i=0;i<strlen(string);i++) { if (i%10==9) yield(); draw(*(string+i),scale,color);}
}

void Hershey::drawStringOpaque(int x,int y,float scale,int fcolor,int bcolor,char * string)
{
	
	int width=getStringSize(string,scale);
	////Serial.print("String width is ");//Serial.print(width);//Serial.print(" for string ");//Serial.println(string);
	tft.fillRect(x,y-16*scale,width,(int)trunc(scale*32),bcolor);
	//Serial.printf("Entered drawStringOpaque with string %s'\n",string);
	drawString(x,y,scale,fcolor,string);
}

void Hershey::drawCenteredString(int y,float scale,int color,char * string)
{
  int xo,yo;
  yo=y;
  int i;
  int len=0;
  for (i=0;i<strlen(string);i++) len+=getSize(string+i,scale);
  yield();
  xo=160-len/2;
  drawString(xo,yo,scale,color,string);
}


int Hershey::getStringSize(char * it,float scale)
{
   int i;
   char * cp=it;
   int w=0;
   for (i=0;i<strlen(it);i++)
   {
     w+=getSize(cp++,scale);
   }
   return w;
}
int Hershey::getSize(char * it,float scale)
{

   float w=0;
   char ch=*it - ' ';
   File fin=SPIFFS.open(fontFile,"r");
   char l,r;
   fin.seek(hFont[ch]+2,SeekSet);
   fin.readBytes(&l,1);
   fin.readBytes(&r,1);
   fin.close();
   w=scale*(-(l - 'R') + (r - 'R'))+0.5;
 //  char buf[64];
 //  sprintf((char *)&buf,"for %c at scale %f width is %d",*it,scale,(int)trunc(w));
 //  //Serial.println((char *)&buf);
   return trunc(w+0.5);
}

int di;
int donePoints=0;
void Hershey::getPt(int indx,float scale,File fin)
{
	char c1,c2;
	fin.readBytes(&c1,1);fin.readBytes(&c2,1);
    if (c1==13) {donePoints=1;Serial.println("Set donePoints");return;}
    //Serial.printf("in getPt indx=%d c1=%c c2=%c\n",indx,c1,c2);
	if (c1==' ' && c2=='R')		
	{indx=1;getPt(0,scale,fin);getPt(1,scale,fin);di++;return;}
  pt[indx][0]=scale*(c1 - 'R')+0.5;
  pt[indx][1]=scale*(c2 - 'R')+0.5;
}
void Hershey::draw(char chr,float scale,int color)
{
	//Serial.printf("Entered Draw with char %c\n",chr);
	donePoints=0;
  char  ch=chr-' ';
 // //Serial.println(chr);
   char buf[100];
   int indx=0;
   int np;
   int i;
   //sprintf((char *)&buf,"%c %c %c %c",*ch++,*ch++,*ch++,*ch++);
   ////Serial.println((char *)&buf);
   ch=chr-' ';
   File fin=SPIFFS.open((char *)&fontFile,"r");
   if (fin!=0) //Serial.printf("draw opened %s\n",&fontFile);
   ////Serial.print(*ch);//Serial.println(*(ch+1));
   fin.seek(hFont[ch],SeekSet); // seek to character to be drawn
   fin.readBytes((char *)&buf,2);buf[2]=0;np=atoi((char *)&buf); // get # points
   //Serial.printf("Char %c has %d pairs\n",chr,np);
   char lc,rc;fin.readBytes(&lc,1);fin.readBytes(&rc,1);
   float l=-scale*(lc - 'R') -0.5;
   ox+=l;
   float r= scale*(rc - 'R')+0.5;
   //Serial.printf("Char %c has width %f\n",chr,l+r);
   int rpt=(int)ceil(scale);
   ////Serial.print("Repeat = ");//Serial.println(rpt);
   ////Serial.println(*cp);
   for (di=1;di<np;di++)
   {
     int rpt=(int)ceil(scale);
     // end of character processinf if (*cp=='#') {ox+=trunc(r+1);if (ox>320-scale*20) {ox=20;oy+=scale*32;}return;}
     // " R" detection if (*cp==' ' && *(cp+1)=='R')  {cp+=2;indx=0;}
	 //Serial.println(di);
	 char ins[2];
	 int pos=fin.position();
	 fin.readBytes((char *)&ins,2);
	 if (ins[0]==' ' && ins[1]=='R') indx=0;
	 else
	 {
	     fin.seek(pos,SeekSet);
		 if (indx==0) {getPt(0,scale,fin); indx=1;di++;}
		 getPt(1,scale,fin);
		 if (abs(pt[1][0]-pt[0][0])<1) // verticle line
		 for (i=0;i<rpt;i++)tft.drawLine(ox+i+pt[0][0],oy+pt[0][1],ox+i+pt[1][0],oy+pt[1][1],color);
		 else if (abs(pt[1][1]-pt[0][1])<1) // horizontal
		 for (i=0;i<rpt;i++)tft.drawLine(ox+pt[0][0],oy+i+pt[0][1],ox+pt[1][0],oy+i+pt[1][1],color);
		 else
		 for (i=0;i<rpt;i++) { tft.drawLine(ox+i+pt[0][0],oy+pt[0][1],ox+i+pt[1][0],oy+pt[1][1],color);
		 tft.drawLine(ox+pt[0][0],oy+i+pt[0][1],ox+pt[1][0],oy+i+pt[1][1],color); }
		 sprintf((char *)&buf,"%f %f %f %f",pt[0][0],pt[0][1],pt[1][0],pt[1][1]);
		 pt[0][0]=pt[1][0];pt[0][1]=pt[1][1];
		 //Serial.println((char *)&buf);
		 if (donePoints==1) break;
	 }
   }
   fin.close();
   ox+=trunc(r+1);
   if (ox>320-scale*20) {ox=5;oy+=scale*32;}
   return;
   
}

void Hershey::drawRotated(int xc,int yc,char chr,float scale,int color,float angle)
{
  char ch=chr-' ';
 float sinr=sin(angle/360.0*2*3.14159);
 float cosr=cos(angle/360.0*2*3.14159);
  angle=angle-90;
  int chngs=1;
  if (angle>90 && angle<270) {angle-=180;chngs=-1;}
 // //Serial.print(chr);//Serial.print(" ");//Serial.print(xc);//Serial.print(" ");//Serial.print(yc);//Serial.print(" ");//Serial.print(scale);//Serial.print(" ");//Serial.print(color);//Serial.print(" ");
 // //Serial.println(angle);
 float sina=sin(angle/360.0*2*3.14159);
 float cosa=cos(angle/360.0*2*3.14159);
   char buf[100];
   int indx=0;
   int i;
   //sprintf((char *)&buf,"%c %c %c %c",*ch++,*ch++,*ch++,*ch++);
   ////Serial.println((char *)&buf);
   ch=chr-' ';
   File fin=SPIFFS.open((char *)&fontFile,"r");
   fin.seek(hFont[ch],SeekSet); // seek to character to be drawn
   int np;
   fin.readBytes((char *)&buf,2);buf[2]=0;np=atoi((char *)&buf);
   char c1,c2;
   fin.readBytes(&c1,1);fin.readBytes(&c2,1);
   float l=-scale*(c1 - 'R') -0.5;
  // ox+=l;
// x'=x*cos(a) -y*sin(a);
// y'=x*sin(a) +y*cos(a); 
    ox=xc+chngs*l*cosa+chngs*deltax;
    oy=yc+chngs*l*sina+chngs*deltay;
   float r= scale*(c2 - 'R')+0.5;
   int rpt=(int)ceil(scale);
   ////Serial.print("Repeat = ");//Serial.println(rpt);
   ////Serial.println(*cp);
   for (di=1;di<np;di++)
   {
     int rpt=(int)ceil(scale);
    // if (*cp=='#') {  deltax=r*cosa+l*cosa;deltay=r*sina+l*sina;return;}
    // if (*cp==' ' && *(cp+1)=='R')  {cp+=2;indx=0;}
	char ins[2];
	 int pos=fin.position();
	 fin.readBytes((char *)&ins,2);
	 if (ins[0]==' ' && ins[1]=='R') indx=0;
	 else
	 {   
		 fin.seek(pos,SeekSet);
		 if (indx==0) {getPt(0,scale,fin); indx=1;di++;float xp=pt[0][0]*cosa - pt[0][1]*sina; float yp=pt[0][0]*sina + pt[0][1]*cosa;pt[0][0]=xp;pt[0][1]=yp;}
		 if (indx==1) {getPt(1,scale,fin);float xp=pt[1][0]*cosa - pt[1][1]*sina;float yp=pt[1][0]*sina + pt[1][1]*cosa;pt[1][0]=xp;pt[1][1]=yp;}
	// x'=x*cos(a) -y*sin(a);
	// y'=x*sin(a) +y*cos(a);
		 if (abs(pt[1][0]-pt[0][0])<1) // verticle line
		 for (i=0;i<rpt;i++)tft.drawLine(ox+i+pt[0][0],oy+pt[0][1],ox+i+pt[1][0],oy+pt[1][1],color);
		 else if (abs(pt[1][1]-pt[0][1])<1) // horizontal
		 for (i=0;i<rpt;i++)tft.drawLine(ox+pt[0][0],oy+i+pt[0][1],ox+pt[1][0],oy+i+pt[1][1],color);
		 else
		 for (i=0;i<rpt;i++) { tft.drawLine(ox+i+pt[0][0],oy+pt[0][1],ox+i+pt[1][0],oy+pt[1][1],color);
		 tft.drawLine(ox+pt[0][0],oy+i+pt[0][1],ox+pt[1][0],oy+i+pt[1][1],color); }
		 sprintf((char *)&buf,"%f %f %f %f",ox+pt[0][0],oy+pt[0][1],ox+pt[1][0],oy+pt[1][1]);
		 pt[0][0]=pt[1][0];pt[0][1]=pt[1][1];
		 ////Serial.println((char *)&buf);
	 }
   }
   fin.close();
   deltax=r*cosa+l*cosa;deltay=r*sina+l*sina;
   return; 
}
