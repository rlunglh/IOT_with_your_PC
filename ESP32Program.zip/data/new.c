drop("main");drop("__exit_value");drop("__argc");drop("__argv");
int main(int argc,char ** argv)
{
   printf("Running program %s\n",(char *)*argv++);
   int i;
   for (i=1;i<11;i++) printf("%2d\n",i);
   return 0;
}