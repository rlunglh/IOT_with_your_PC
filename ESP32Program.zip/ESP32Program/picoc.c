/* picoc main program - this varies depending on your operating system and
 * how you're using picoc */
 
/* include only picoc.h here - should be able to use it with only the external interfaces, no internals from interpreter.h */
#include "picoc.h"

/* platform-dependent code for running programs is in this file */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
extern char * Prompt;
#define PICOC_STACK_SIZE 20000
/* space for the the stack */
extern char buf[BUFSIZE];
int picoc_main()
{
    int i;
    for (i=0;i<BUFSIZE;i++) buf[i]=0;
    int DontRunMain = FALSE;
    int StackSize = PICOC_STACK_SIZE;
    PicocInitialise(StackSize);
    
    Prompt = "picoc> ";
    PicocIncludeAllSystemHeaders(1);
    PicocParseInteractive();
    
    
    PicocCleanup();
    return PicocExitValue;
}
