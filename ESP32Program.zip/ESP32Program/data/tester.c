drop("main");
//setConsoleOn(1);TFT_setTextSize(1);
ls();
printf("\n");
cat("/tester.c",1);

void main()
{ printf("Program Done\n");}