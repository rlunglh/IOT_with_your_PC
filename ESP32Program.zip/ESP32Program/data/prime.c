drop("main");drop("__exit_value");
int main()
{
  int t1,start=1001,end=4000,mcount=0, k, n, lim, sn, p, pc=0, lastp=0, phold=0,rpt=100;   
  t1=sysTime(); n = start; lastp=n; lim = end; sn=n;	
  printf("Finding primes between %, and %,\n\n",n,lim);
  while (n<lim)
  {
    k = 3; p = 1; n = n + 2;
    while ((k * k <= n) && p)
    {  
      p = n/k*k-n; mcount++; k = k + 2;
    }
    if (p)
    {
      pc = pc + 1; phold=n;
      if (pc%rpt==0)
      {
        printf("prime # %5, is %7, in this range %4.2f percent are primes\n",pc,n,(float)rpt*100.0/(n-lastp));
        lastp=n;
      }
    }
  }
  float runsec=(sysTime()-t1);
  printf("\n\nFound %, primes\n", pc);	
  printf("Last prime was %,\n\n",phold);	
  printf("It took %6.2f seconds to process\n",runsec/1000.0);
  int pers=1000.0*mcount/runsec;
  printf("%, loops were performed, that's %, per second\n",mcount,pers);
  return 1;
}