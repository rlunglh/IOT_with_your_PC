drop("main");drop("__exit_value");
int main()
{
   int i;
   printf("square root of 2 is %0.5f\n",sqrt(2));
   printf("print with commas 123456789 is %,\n",123456789);
   printf("atoi(\"2000000000\") is %,\n",atoi("2000000000"));
   printf("size of char is %d\n",sizeof(char));
   printf("size of short is %d\n",sizeof(short));
   printf("size of int is %d\n",sizeof(int));
   printf("size of long is %d\n",sizeof(long)); 
   printf("size of float is %d\n",sizeof(float));
   printf("size of double is %d\n",sizeof(double));
   return i;
}