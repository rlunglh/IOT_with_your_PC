void main()
{
  int i;
  oClearDisplay();
  oDisplay();
  char cb[20];
  for (i=0;i<20;i++)
  {
	sprintf((char *)&cb, "line %d",i);
	oConsolePrintln((char *)&cb);
  }
}