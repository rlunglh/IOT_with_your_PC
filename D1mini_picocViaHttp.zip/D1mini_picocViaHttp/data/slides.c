void slides(int sleep) {
	 fillScreen(0xffff);
     drawJpeg("/misLogo.jpg",0,0);
     delay(sleep);
     drawJpeg("/mini.jpg",0,0);
     delay(sleep);
     drawJpeg("/WeMoLogo.jpg",0,0);
     delay(sleep);
}
