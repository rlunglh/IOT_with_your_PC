/* test program */

main()
{
    int j;
	lcprintf("Hello from little c interpreter\n\n");
	j = 11;
	printf("Values of a sequence with %% at beginning %d %2d %3d %4d\n",j,j+1,j-2,14);
	printf("Values of a sequence with %% at beginning %X %2X %3X %4X\n",j,j+1,j-2,14);
	printf("The value of j<11 is %d\n",j<11);
	printf("The value of j<=11 is %d\n",j<=11);
	for (j = 0; j < 32; j = j + 1) { printf("%2d %02x\n", j,j); }
	return ;
}