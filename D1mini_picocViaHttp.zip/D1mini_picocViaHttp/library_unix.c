#include "interpreter.h"
#include "picoc.h"
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
   
extern char buf[BUFSIZE];
void UnixSetupFunc()
{    
}
char * PlatformReadFile(char * FileName);


void Clineno (struct ParseState *Parser, struct Value *ReturnValue, struct Value **Param, int NumArgs) 
{
    ReturnValue->Val->Integer = Parser->Line;
}

void irand (struct ParseState *Parser, struct Value *ReturnValue, struct Value **Param, int NumArgs) 
{
    ReturnValue->Val->Integer = rand();
}
void picocexit (struct ParseState *Parser, struct Value *ReturnValue, struct Value **Param, int NumArgs) 
{
     printf("picoc Exiting\n\n");
    
}


void Sleep(struct ParseState *Parser, struct Value *ReturnValue, struct Value **Param, int NumArgs)
{
   int sval=Param[0]->Val->Integer;
   delay(sval);
}

void sprint(char *);

void send(char * it);
void sendln(char * it);
void CurLinePrint(struct ParseState * Parser)
{
        int i=1;
        char fbuf[133];
        int line=Parser->Line;
        int pos=Parser->CharacterPos;
        PlatformReadFile(Parser->FileName); 
        char * ps,*cp;
        cp=(char *)&buf;ps=strchr(cp,10);
        while (ps!=0)
        {
          if (i==line)
          {
            *ps=0;
            int j;
            sprintf((char *)&fbuf,"%4d:%d  >",i,pos);
            sprint((char *)&fbuf);
            printf("%s\n",(char *)cp);
            send((char *)&fbuf);
            for (j=0;j<pos+11;j++) printf(" ");                       
            printf("%s\n","^");
            send((char *)&fbuf);
            *ps++=10;return;
          }
          else {i++;
            cp=++ps;
            ps=strchr(cp,10); }
        }
}

void prntLines(struct ParseState * Parser)
{
  int i=1;
  char fbuf[133];fbuf[0]=0;
  int line=Parser->Line;
  PlatformReadFile(Parser->FileName); 
  char * ps,*cp;cp=(char *)&buf;ps=strchr(cp,10);
  while (ps!=0)
  {
      *ps=0;
      sprintf((char *)&fbuf,"%4d >%s\n",i,(char *)cp);
  //    printf("%s",(char *)&fbuf);
      send((char *)&fbuf);
      *ps++=10;cp=ps;i++;ps=strchr(cp,10);    
  }
  if (*cp!=0) {
      sprintf((char *)&fbuf,"%4d >%s\n",i,(char *)cp);
      printf((char *)&fbuf);
      send((char *)&fbuf);
  }
}
void LinePrint(char * src,int line,int col)
{
        printf("Entered PrintLine");
        char * strt=(char *)buf;
        int i=1;
        char work[128];
        int dn=0;
        strncpy((char *)buf,src,2999);
        printf("\r\n");
        sendln("\r\n");

        char *where=strchr(strt,'\n');
        while (dn==0 && where !=(void *)0)
        {
        where=strchr(strt,'\n');
                if (where!=0)
                {
                        *where=0;
                        sprintf((char *)&work,"%4d %s\r\n",i++,strt);
                        printf("%s",(char *)&work);
                        send((char *)&work);
                        if (line==i-1) // printed the line being executed
                        {
                                        int j; for (j=0;j<col+5;j++) printf(" ");
                                        printf("^\r\n");
                        }
                        strt=where;
                        strt++;
                }
                else
                {
                        //dn=1;
                        if (strlen(strt)!=0) { sprintf((char *)&work,"%4d %s\r\n",i,strt);printf((char *)&work);send((char *)&work); }
                }

        }
}



extern char * Prompt;


/* list of all library functions and their prototypes */
struct LibraryFunction UnixFunctions[] =
{
    { Clineno,      "int lineno();" },
    { picocexit,    "void picocexit();" },
    { Sleep,       "void  Sleep(int);" },
    { NULL,         NULL }
};

void PlatformLibraryInit()
{
    IncludeRegister("picoc_unix.h", &UnixSetupFunc, &UnixFunctions[0], NULL);
}

