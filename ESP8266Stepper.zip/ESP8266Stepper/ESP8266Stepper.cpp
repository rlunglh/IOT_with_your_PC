#include "ESP8266Stepper.h"

// define DEBUG to get verbose output on Serial Monitor
//#define DEBUG

byte pins[] = { 15,14,12,16 };
void ESP8266Stepper::setPins()
{
	int i;
	for (i=0;i<4;i++) // turn off outputs before turning on outputs
		if ((steps[stepIndex] & bitmask[i])!=bitmask[i]) digitalWrite(pins[i],0);
	for (i=0;i<4;i++)
		if ((steps[stepIndex] & bitmask[i])==bitmask[i]) digitalWrite(pins[i],1);
}

void ESP8266Stepper::newVal()
{
// calculates nex index by ading direction and wrapping of + or - overflow
	stepIndex+=CcW;
	if (stepIndex>7) stepIndex=0;
	if (stepIndex<0) stepIndex=7;
	return ;
}
int ESP8266Stepper::doingSweeping()
{
	// report sweeping status
	return sweeping;
}

void ESP8266Stepper::oscillate(float angle,int dir,float time)
{
	// oscillate over angle over time
	updateInterval=time*1000/(angle/360*stepsPerRevolution); // milliseconds between updates;
	if (updateInterval<1) {Serial.printf("UpdateInterval=%f that's too fast!\n",updateInterval);return;}
	CcW=dir;
	doneUpdates=0;
	Serial.printf("\nUpdateInterval=%f \n",updateInterval);
	lastUpdate=micros(); // get time hack to calculate elapsed time in millisecs
	cycling=1;
	sweepTime=time;
#ifdef DEBUG
	Serial.printf("Oscillate on sweepTime=%f, updateInterval=%f, cycling=%d\n",sweepTime,updateInterval,cycling);
#endif	
}
  
ESP8266Stepper::ESP8266Stepper() // initialize with pin definitions from pins[]
{
	// initialize stepper on pin with default min mid and max values

	for (int i=0;i<4; i++) pinMode(pins[i],OUTPUT);
	sweeping=0;
	cycling=0;
}
  
void ESP8266Stepper::report()
{
	// Serial output of stepper position information
  Serial.printf("stepping=%d cycling=%d\n",sweeping,cycling);
}

void ESP8266Stepper::step(int steps,int dir,int speed)
{
	stepsPerUpdate=1;
    updateInterval= 1000*speed;
	doneUpdates=0;
	Serial.printf("\nUpdateInterval=%f \n",updateInterval);
	CcW=dir;
	lastUpdate=micros();
	sweeping=1; // used to enable processing in sweepUpdate
	sweepTime=steps*speed;
#ifdef DEBUG
	Serial.printf("Step on updateInterval=%f, sweeping=%d\n",updateInterval,sweeping);
#endif	
}
 
void ESP8266Stepper::sweep(float angle,int dir,float time)
{
	// sweep from current position over Angle over time
	
	stepsPerUpdate=1;
	updateInterval=10*(time*100000/(angle/360*stepsPerRevolution)); // microseconds between updates;
	if (updateInterval<1) {
	Serial.printf("\nUpdateInterval=%f that's too fast! Try a longer time value\n",updateInterval);return;}
	doneUpdates=0;
	Serial.printf("\nUpdateInterval=%f \n",updateInterval);
	CcW=dir;
	lastUpdate=micros();
	sweeping=1; // used to enable processing in sweepUpdate
	sweepTime=time;
#ifdef DEBUG
	Serial.printf("Sweep on updateInterval=%f, sweeping=%d\n",updateInterval,sweeping);
#endif	
}
void ESP8266Stepper::continuousSweep(float angle,int dir,float time)
{
	// sweep from current position over Angle over time
	stepsPerUpdate=1;
	updateInterval=10*(time*100000/(angle/360*stepsPerRevolution)); // microseconds between updates;
		if (updateInterval<200) {
		Serial.printf("\nUpdateInterval=%f that's too fast! Try a longer time value\n",updateInterval);return;}
	doneUpdates=0;
	Serial.printf("\nUpdateInterval=%f \n",updateInterval);
	CcW=dir;
	lastUpdate=micros();
	sweeping=-1; // used to enable processing in sweepUpdate
	sweepTime=time;
#ifdef DEBUG
	Serial.printf("Sweep on updateInterval=%f, sweeping=%d\n",updateInterval,sweeping);
#endif	
}
/* the sweepUpdate function should be called in your loop function
* if you use the sweep function in your sketch
*******************************************************************/
void ESP8266Stepper::sweepUpdate()
{
	// used in loop function to implement sweep updates
	if (sweeping==0) return; // return if not sweeping
	int numDeltas;
	unsigned int cTime=micros(); // get current time
	if (cTime<lastUpdate) {lastUpdate=cTime;return;}
	int deltaTime=cTime-lastUpdate;
	if (deltaTime>=trunc(updateInterval)) // if update interval has passed do a position update
	{
		//if (doneUpdates<50) Serial.printf("%d\n",deltaTime);
		numDeltas=trunc(deltaTime/trunc(updateInterval));
		if (numDeltas==0) return;
		newVal(); setPins(); 
		lastUpdate=cTime-deltaTime+trunc(updateInterval); // set last update to now
		doneUpdates+=numDeltas;
		if (sweeping !=-1 && doneUpdates*updateInterval>=sweepTime*1000) sweeping=0;
		// time has elapsed stop sweeping unless running continous
	}
#ifdef DEBUG
	if (numDeltas>=1)Serial.printf("Sweeping on Dir=%d stepIndex=%d UpdateTime=%f\n",CcW,stepIndex,doneUpdates*updateInterval);
#endif	
}

/* the oscillateUpdate function should be called in your loop function
* if you use the oscillate function in your sketch
*******************************************************************/
void ESP8266Stepper::oscillateUpdate()
{
	// used in loop function to do oscillate updates
	if (!cycling) return; // return if not cycling
	int numDeltas;
	unsigned int cTime=micros(); // get current time
	if (cTime<lastUpdate) {lastUpdate=cTime;return;}
	int deltaTime=cTime-lastUpdate;
	if (deltaTime>=trunc(updateInterval)) //  only process if delta time has passed
	{
		numDeltas=trunc(deltaTime/trunc(updateInterval));
		if (numDeltas==0) return;
		newVal();
		setPins();
		lastUpdate=cTime-deltaTime+trunc(updateInterval);
		doneUpdates+=numDeltas;
		if (doneUpdates*updateInterval>=sweepTime*1000) 
		{
			// if an oscillate sequence time has expired sweep in oposite direction
			CcW*=-1;
			doneUpdates=0;
		}
	}
#ifdef DEBUG
	if (numDeltas>=1) Serial.printf("Oscillating in dir=%d stepIndex=%d time=%f\n",CcW,stepIndex,doneUpdates*updateInterval);
#endif	
}

