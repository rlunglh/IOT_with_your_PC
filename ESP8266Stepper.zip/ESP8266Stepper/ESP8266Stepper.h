#ifndef ESP8266Stepper_h
#define ESP8266Stepper_h

#if (ARDUINO >= 100)
#include <Arduino.h>
#else
#include <WProgram.h>
#endif

#define stepsPerRevolution 4076

class ESP8266Stepper
{
public:
  ESP8266Stepper(); // initialize stepper 
  void setPins();
  void newVal();
  void step(int steps,int CcW,int speed); // take steps ste in CcW direction with each step taking speed milliseconds
  void sweep(float toAngle, int dir,float time); // change to toAngle over time seconds
  void continuousSweep(float toAngle, int dir,float time); // change at toAngle/time deg/sec in direction dir
  void oscillate(float Angle,int dir,float time); // sweep between two points over time seconds
  void sweepUpdate(); // run in loop function to execute sweep updates
  void oscillateUpdate(); // run in loop to execute oscillate updates
  void report(); // Serial output current stepper information
  int doingSweeping(); // status check to inquire if doing sweeping
private:
  int stepIndex=0;
  int CcW=1; // 1 is clockwise -1 is counter clockwise
  int cycling=0;
  int stepsPerUpdate;
  int sweeping, doneUpdates;
  unsigned int lastUpdate;
  float deltaPos, sweepTime, updateInterval;
  int steps[8]={0x1000,0x1100,0x0100,0x0110,0x0010,0x0011,0x0001,0x1001};
  int bitmask[4]={0x1000,0x0100,0x0010,0x0001};
};

#endif